<?php
require '../dbConfig.php';
require '../dbConfigs.php';

// Fetch types for the filter dropdown
$type_sql = "SELECT * FROM type";
$type_stmt = $pdo->prepare($type_sql);
$type_stmt->execute();
$types = $type_stmt->fetchAll(PDO::FETCH_ASSOC);

// Default query
$sql = "
    SELECT 
        product.ID as product_id, product.image, product.Name, product.price, 
        detail_product.detail, detail_product.amount, 
        type.type
    FROM 
        product
    JOIN 
        detail_product ON product.detail_id = detail_product.ID
    JOIN 
        type ON detail_product.type_id = type.ID
    WHERE 1=1
";

// Add filtering conditions if form is submitted
if (isset($_GET['filter'])) {
    if (!empty($_GET['type'])) {
        $sql .= " AND type.ID = :type_id";
    }
    if (!empty($_GET['min_price']) && !empty($_GET['max_price'])) {
        $sql .= " AND product.price BETWEEN :min_price AND :max_price";
    }
}

// Prepare and execute query with filtering parameters
$stmt = $pdo->prepare($sql);

// Bind parameters for the filters if they are set
if (isset($_GET['filter'])) {
    if (!empty($_GET['type'])) {
        $stmt->bindValue(':type_id', $_GET['type']);
    }
    if (!empty($_GET['min_price']) && !empty($_GET['max_price'])) {
        $stmt->bindValue(':min_price', $_GET['min_price']);
        $stmt->bindValue(':max_price', $_GET['max_price']);
    }
}

$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Cards with Filters</title>
    <style>
        .product-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            justify-content: center;
        }

        .card {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 16px;
            margin: 16px;
            width: 250px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 400px;
            /* Set minimum height */
        }

        .card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            cursor: pointer;
            /* Add cursor pointer */
        }

        .card h2 {
            font-size: 18px;
            margin: 8px 0;
        }

        .card p {
            margin: 4px 0;
        }

        .price {
            font-size: 16px;
            color: green;
            font-weight: bold;
        }

        .filter-form {
            margin-bottom: 20px;
        }

        .filter-form label,
        .filter-form select,
        .filter-form input {
            margin-right: 10px;
        }

        /* Modal styles */
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 900px;
            border-radius: 8px;
            text-align: center;
            position: relative;
            color: black;
         
        }

        .modal h2,
        .modal p {
            color: black;
            
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            border-radius: 8px;
            text-align: center;
            position: relative;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 20px;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .modal img {
            width: 100%;
            max-height: 500px;
            object-fit: cover;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

    <h1>Product Cards with Filters</h1>

    <!-- Filter Form -->
    <form method="GET" class="filter-form">
        <label for="type">Product Type:</label>
        <select name="type" id="type">
            <option value="">-- Select Type --</option>
            <?php foreach ($types as $type): ?>
                <option value="<?php echo htmlspecialchars($type['ID']); ?>"
                    <?php if (isset($_GET['type']) && $_GET['type'] == $type['ID']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($type['type']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="min_price">Min Price:</label>
        <input type="number" name="min_price" id="min_price" value="<?php echo isset($_GET['min_price']) ? htmlspecialchars($_GET['min_price']) : ''; ?>">

        <label for="max_price">Max Price:</label>
        <input type="number" name="max_price" id="max_price" value="<?php echo isset($_GET['max_price']) ? htmlspecialchars($_GET['max_price']) : ''; ?>">

        <button type="submit" name="filter">Filter</button>
    </form>

    <!-- Product Cards -->
    <div class="product-grid">
        <?php if (empty($products)): ?>
            <p>No products found.</p>
        <?php else: ?>
            <?php foreach ($products as $product): ?>
                <div class="card">
                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="Product Image">
                    <h2><?php echo htmlspecialchars($product['Name']); ?></h2>
                    <p class="price">$<?php echo number_format($product['price'], 2); ?></p>
                    <p>Amount: <?php echo htmlspecialchars($product['amount']); ?></p>
                    <p>Type: <?php echo htmlspecialchars($product['type']); ?></p>
                    <p><?php echo htmlspecialchars($product['detail']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Modal Structure -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <img id="modalImage" src="" alt="Product Image">
            <h2 id="modalName"></h2>
            <p class="price" id="modalPrice"></p>
            <p>Amount: <span id="modalAmount"></span></p>
            <p>Type: <span id="modalType"></span></p>
            <p id="modalDetail"></p>
        </div>
    </div>

    <script>
        // Get the modal and close button elements
        const modal = document.getElementById('productModal');
        const modalImg = document.getElementById('modalImage');
        const modalName = document.getElementById('modalName');
        const modalPrice = document.getElementById('modalPrice');
        const modalAmount = document.getElementById('modalAmount');
        const modalType = document.getElementById('modalType');
        const modalDetail = document.getElementById('modalDetail');
        const closeModalBtn = document.querySelector('.close');

        // Add event listeners to all product images
        document.querySelectorAll('.card img').forEach((img) => {
            img.addEventListener('click', function() {
                const card = this.closest('.card');
                const name = card.querySelector('h2').textContent;
                const price = card.querySelector('.price').textContent;
                const amount = card.querySelector('p:nth-of-type(2)').textContent.split(': ')[1];
                const type = card.querySelector('p:nth-of-type(3)').textContent.split(': ')[1];
                const detail = card.querySelector('p:nth-of-type(4)').textContent;

                // Set the modal content
                modalImg.src = this.src;
                modalName.textContent = name;
                modalPrice.textContent = price;
                modalAmount.textContent = amount;
                modalType.textContent = type;
                modalDetail.textContent = detail;

                // Show the modal
                modal.style.display = 'block';
            });
        });

        // Close modal when the close button is clicked
        closeModalBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });

        // Close modal when clicking outside the modal content
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    </script>

</body>

</html>