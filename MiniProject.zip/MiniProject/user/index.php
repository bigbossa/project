<?php

include 'head.php';
include 'nav.php';

?>
<br><br><br><br>
<?php include 'slidebar.php'; ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
                    <?php 
                    include 'content.php'; 
                    ?>
        </div>
    </div>
</div>
<?php
include 'footer.php';
include 'javaScrip.php';
include 'fixed-plugin.php';
?>

