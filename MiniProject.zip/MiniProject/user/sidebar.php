<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="javascript:void(0)" class="simple-text logo-mini">
                JTP
            </a>
            <a href="javascript:void(0)" class="simple-text logo-normal">
                |  jaturapat
            </a>
        </div>
        <ul class="nav">
            <li>
                <a href="index.php">
                    <i class="tim-icons icon-pin"></i>
                    <p>Home</p>
                </a>
            </li>
            <li>
                <a href="index_edituser.php">
                    <i class="tim-icons icon-pin"></i>
                    <p>Edituser</p>
                </a>
            </li>
            <li>
                <a href="../logout.php">
                    <i class="tim-icons icon-pin"></i>
                    <p>Logout</p>
                </a>
            </li>

            
        </ul>
    </div>
</div>