<?php
session_start();
require_once 'dbConfig.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับข้อมูลจากฟอร์ม
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $fname = $_POST['fname']; // รับข้อมูล fname
    $lname = $_POST['lname']; // รับข้อมูล lname

    // ตรวจสอบว่ารหัสผ่านและยืนยันรหัสผ่านตรงกันหรือไม่
    if ($password === $confirm_password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // ตรวจสอบว่ามีอีเมลหรือชื่อผู้ใช้นี้อยู่แล้วหรือไม่
        $sql = "SELECT * FROM User WHERE Email = ? OR User = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $username); // ถ้าใช้ MySQLi
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            echo "อีเมลหรือชื่อผู้ใช้นี้ถูกใช้แล้ว!";
        } else {
            // เริ่มต้น transaction เพื่อบันทึกข้อมูลใน 2 ตาราง
            $conn->begin_transaction();
            
            try {
                // บันทึกข้อมูลลงในตาราง Profile
                $sql = "INSERT INTO Profile (fname, lname) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $fname, $lname);
                $stmt->execute();
                
                // ดึง id ที่ถูกสร้างจากตาราง Profile
                $profile_id = $conn->insert_id;

                // บันทึกข้อมูลลงในตาราง User พร้อมกับเชื่อมโยง profile_id
                $sql = "INSERT INTO User (Email, Password, User, profile_id) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssi", $email, $hashed_password, $username, $profile_id);

                if ($stmt->execute()) {
                    // ทำ commit เพื่อบันทึกข้อมูล
                    $conn->commit();
                    echo "ลงทะเบียนสำเร็จ!";
                    header('Location: login.php');
                    exit();
                } else {
                    // หากเกิดข้อผิดพลาด ทำ rollback
                    $conn->rollback();
                    echo "เกิดข้อผิดพลาดในการลงทะเบียน!";
                }
            } catch (Exception $e) {
                // หากมีข้อผิดพลาด ทำ rollback
                $conn->rollback();
                echo "เกิดข้อผิดพลาด: " . $e->getMessage();
            }
        }
    } else {
        echo "รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน!";
    }
}
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Form | DataShop</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="wrapper">
        <form action="register.php" method="POST">
            <h2>Register</h2>
            <div class="input-field">
                <input type="text" name="username" required>
                <label>Enter your username</label>
            </div>
            <div class="input-field">
                <input type="text" name="fname" required>
                <label>Enter your first name</label>
            </div>
            <div class="input-field">
                <input type="text" name="lname" required>
                <label>Enter your last name</label>
            </div>

            <div class="input-field">
                <input type="text" name="email" required>
                <label>Enter your email</label>
            </div>
            <div class="input-field">
                <input type="password" name="password" required>
                <label>Enter your password</label>
            </div>
            <div class="input-field">
                <input type="password" name="confirm_password" required>
                <label>Enter your Confirm password</label>
            </div>

            <button type="submit">Register</button>
            <div class="register">
                <p>Already have an account? <a href="login.php">Login</a></p>
            </div>
        </form>
    </div>
</body>

</html>
