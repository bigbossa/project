<?php
session_start();
require_once 'dbConfig.php';
require_once 'dbConfigs.php';

// ตรวจสอบว่าผู้ใช้ล็อกอินอยู่แล้วหรือไม่
if (isset($_SESSION['id'])) {
    if ($_SESSION['role'] == 1) {
        header('Location: admin/index.php'); // สำหรับ Admin
    } else {
        header('Location: user/index.php'); // สำหรับ User
    }
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับข้อมูลจากฟอร์ม
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        // ตรวจสอบข้อมูลอีเมลจากฐานข้อมูล
        $sql = "SELECT * FROM User WHERE Email = ?";
        $stmt = $conn->prepare($sql); // ใช้ MySQLi หรือ PDO ขึ้นอยู่กับการตั้งค่า dbConfig.php
        $stmt->bind_param("s", $email); // ถ้าใช้ MySQLi
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            // ตรวจสอบรหัสผ่าน
            if (password_verify($password, $user['Password'])) {
                session_regenerate_id(); // ป้องกัน session fixation
                $_SESSION['id'] = $user['ID']; // เก็บ ID ผู้ใช้ใน session
                $_SESSION['email'] = $user['Email'];
                $_SESSION['username'] = $user['User']; // ถ้ามีชื่อผู้ใช้ในฐานข้อมูล
                $_SESSION['role'] = $user['role']; // เก็บ role ของผู้ใช้ใน session

                // ตรวจสอบบทบาทของผู้ใช้
                if ($user['role'] == 1) {
                    // สำหรับ Admin
                    header('Location: admin/index.php');
                } else {
                    // สำหรับ User
                    header('Location: user/index.php');
                }
                exit();
            } else {
                $error_message = "รหัสผ่านไม่ถูกต้อง!";
            }
        } else {
            $error_message = "ไม่พบอีเมลนี้ในระบบ!";
        }
    } catch (mysqli_sql_exception $e) {
        $error_message = "เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form | DataShop</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="wrapper">
        <form action="" method="POST">
            <h2>Login</h2>
            <div class="input-field">
                <input type="email" name="email" required>
                <label>Enter your email</label>
            </div>
            <div class="input-field">
                <input type="password" name="password" required>
                <label>Enter your password</label>
            </div>

            <div class="forget">
                <label for="remember">
                    <input type="checkbox" id="remember">
                    <p>Remember me</p>
                </label>
                <a href="#">Forgot password?</a>
            </div>

            <?php if (isset($error_message)): ?>
                <div class="error-message">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <button type="submit">Log In</button>
            <div class="register">
                <p>Don't have an account? <a href="register.php">Register</a></p>
            </div>
        </form>
    </div>
</body>

</html>
