<?php
// ข้อมูลการเชื่อมต่อฐานข้อมูล
$servername = "localhost"; // หรือชื่อโฮสต์ของคุณ
$username = "root";        // ชื่อผู้ใช้งานของฐานข้อมูล
$password = "";            // รหัสผ่านของฐานข้อมูล
$dbname = "DataShop";      // ชื่อฐานข้อมูลของคุณ

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// echo "Connected successfully";
?>
