<?php
require_once 'ProductRepository.php';

class ProductController {
    private $repository;

    public function __construct(ProductRepository $repository) {
        $this->repository = $repository;
    }

    public function displayProducts() {
        // Fetch types for the dropdown
        $types = $this->repository->getTypes();

        // Fetch products based on filters
        $filters = [
            'type' => $_GET['type'] ?? null,
            'min_price' => $_GET['min_price'] ?? null,
            'max_price' => $_GET['max_price'] ?? null,
        ];
        $products = $this->repository->getProducts($filters);

        // Include the HTML template for rendering
        include 'product_view.php';
    }
}
?>
