<?php
require_once 'Database.php';
require_once 'Product.php';

class ProductRepository {
    private $pdo;

    public function __construct(Database $db) {
        $this->pdo = $db->pdo;
    }

    public function getTypes() {
        $type_sql = "SELECT * FROM type";
        $stmt = $this->pdo->prepare($type_sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getProducts($filters = []) {
        $sql = "
            SELECT 
                product.ID as product_id, product.image, product.Name, product.price, 
                detail_product.detail, detail_product.amount, 
                type.type
            FROM 
                product
            JOIN 
                detail_product ON product.detail_id = detail_product.ID
            JOIN 
                type ON detail_product.type_id = type.ID
            WHERE 1=1
        ";

        // Apply filters if they are set
        if (!empty($filters['type'])) {
            $sql .= " AND type.ID = :type_id";
        }
        if (!empty($filters['min_price']) && !empty($filters['max_price'])) {
            $sql .= " AND product.price BETWEEN :min_price AND :max_price";
        }

        $stmt = $this->pdo->prepare($sql);

        // Bind parameters for the filters if they are set
        if (!empty($filters['type'])) {
            $stmt->bindValue(':type_id', $filters['type']);
        }
        if (!empty($filters['min_price']) && !empty($filters['max_price'])) {
            $stmt->bindValue(':min_price', $filters['min_price']);
            $stmt->bindValue(':max_price', $filters['max_price']);
        }

        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Convert data to Product objects
        $productList = [];
        foreach ($products as $product) {
            $productList[] = new Product(
                $product['product_id'],
                $product['image'],
                $product['Name'],
                $product['price'],
                $product['detail'],
                $product['amount'],
                $product['type']
            );
        }

        return $productList;
    }
}
?>
