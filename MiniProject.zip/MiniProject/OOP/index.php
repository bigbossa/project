<?php
include 'head.php';
include 'nav.php';
include 'slidebar.php'; 

require_once 'Database.php';
require_once 'ProductRepository.php';
require_once 'ProductController.php';

// Initialize Database, Repository, and Controller
$db = new Database();
$productRepo = new ProductRepository($db);
$productController = new ProductController($productRepo);

// Display Products
$productController->displayProducts();
include 'footer.php';
include 'javaScrip.php';
include 'fixed-plugin.php';
?>
