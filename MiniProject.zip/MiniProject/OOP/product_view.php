<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Cards with Filters</title>
    <!-- Your styles here -->
</head>
<body>
    <h1>Product Cards with Filters</h1>

    <!-- Filter Form -->
    <form method="GET" class="filter-form">
        <label for="type">Product Type:</label>
        <select name="type" id="type">
            <option value="">-- Select Type --</option>
            <?php foreach ($types as $type): ?>
                <option value="<?php echo htmlspecialchars($type['ID']); ?>"
                    <?php if (isset($_GET['type']) && $_GET['type'] == $type['ID']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($type['type']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="min_price">Min Price:</label>
        <input type="number" name="min_price" id="min_price" value="<?php echo isset($_GET['min_price']) ? htmlspecialchars($_GET['min_price']) : ''; ?>">

        <label for="max_price">Max Price:</label>
        <input type="number" name="max_price" id="max_price" value="<?php echo isset($_GET['max_price']) ? htmlspecialchars($_GET['max_price']) : ''; ?>">

        <button type="submit" name="filter">Filter</button>
    </form>

    <!-- Product Cards -->
    <div class="product-grid">
        <?php if (empty($products)): ?>
            <p>No products found.</p>
        <?php else: ?>
            <?php foreach ($products as $product): ?>
                <div class="card">
                    <img src="<?php echo htmlspecialchars($product->image); ?>" alt="Product Image">
                    <h2><?php echo htmlspecialchars($product->name); ?></h2>
                    <p class="price">$<?php echo number_format($product->price, 2); ?></p>
                    <p>Amount: <?php echo htmlspecialchars($product->amount); ?></p>
                    <p>Type: <?php echo htmlspecialchars($product->type); ?></p>
                    <p><?php echo htmlspecialchars($product->detail); ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
