<?php
class Product {
    public $id;
    public $image;
    public $name;
    public $price;
    public $detail;
    public $amount;
    public $type;

    public function __construct($id, $image, $name, $price, $detail, $amount, $type) {
        $this->id = $id;
        $this->image = $image;
        $this->name = $name;
        $this->price = $price;
        $this->detail = $detail;
        $this->amount = $amount;
        $this->type = $type;
    }
}
?>
