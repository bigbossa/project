<?php
$host = 'localhost';
$db = 'DataShop';
$user = 'root'; // ใส่ชื่อผู้ใช้ฐานข้อมูลของคุณ
$pass = ''; // ใส่รหัสผ่านฐานข้อมูลของคุณ

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
