<?php
require_once '../condb.php'; 

if (session_status() === PHP_SESSION_NONE) {

    session_start();
}

echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $user_id = $_SESSION['user_login'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];


    if ($new_password !== $confirm_password) {
        echo '<script>
            setTimeout(function() {
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "รหัสผ่านใหม่ไม่ตรงกับการยืนยัน",
                    showConfirmButton: false,
                    timer: 2000
                }).then(function() {
                    window.location = "change_password.php";
                });
            }, 1000);
        </script>';
        exit();
    }

    $sql = "SELECT password FROM tb_users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(1, $user_id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);


    if (!password_verify($current_password, $user['password'])) {
        echo '<script>
            setTimeout(function() {
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "รหัสผ่านเก่าไม่ถูกต้อง",
                    showConfirmButton: false,
                    timer: 2000
                }).then(function() {
                    window.location = "change_password.php";
                });
            }, 1000);
        </script>';
        exit();
    }


    $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $sql = "UPDATE tb_users SET password = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(1, $new_password_hashed);
    $stmt->bindParam(2, $user_id);
    $stmt->execute();

    echo '<script>
        setTimeout(function() {
            Swal.fire({
                position: "center",
                icon: "success",
                title: "เปลี่ยนรหัสผ่านสำเร็จ",
                showConfirmButton: false,
                timer: 2000
            }).then(function() {
                window.location = "index.php";
            });
        }, 1000);
    </script>';
    exit();
}
?>
