-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2024 at 05:28 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `datashop`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_product`
--

CREATE TABLE `detail_product` (
  `ID` int(11) NOT NULL,
  `detail` text DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_product`
--

INSERT INTO `detail_product` (`ID`, `detail`, `amount`, `type_id`) VALUES
(3, 'หน้าจอแสดงผลขนาด 15.3\" Liquid Retina display\r\nหน่วยประมวลผล Apple M3\r\nNeural Engine ชิปเซ็ตพิเศษที่โฟกัสการทำงานให้กับเทคโนโลยี AI\r\nมาพร้อมตัวจัดเก็บ SSD 256GB และ หน่วยความจำรวมขนาด 8GB\r\nมาพร้อมระบบปฏิบัติการ mac OS', 99, 2),
(4, 'หน้าจอแสดงผลขนาด 15.3\" Liquid Retina displayหน่วยประมวลผล Apple M3Neural Engine ชิปเซ็ตพิเศษที่โฟกัสการทำงานให้กับเทคโนโลยี AIมาพร้อมตัวจัดเก็บ SSD 256GB และ หน่วยความจำรวมขนาด 8GBมาพร้อมระบบปฏิบัติการ mac OS', 10, NULL),
(5, 'หน้าจอแสดงผลขนาด 15.3\" Liquid Retina display\r\nหน่วยประมวลผล Apple M3\r\nNeural Engine ชิปเซ็ตพิเศษที่โฟกัสการทำงานให้กับเทคโนโลยี AI\r\nมาพร้อมตัวจัดเก็บ SSD 256GB และ หน่วยความจำรวมขนาด 8GB\r\nมาพร้อมระบบปฏิบัติการ mac OS', 99, 2),
(6, 'หน้าจอแสดงผลขนาด 15.3\" Liquid Retina display\r\nหน่วยประมวลผล Apple M3\r\nNeural Engine ชิปเซ็ตพิเศษที่โฟกัสการทำงานให้กับเทคโนโลยี AI\r\nมาพร้อมตัวจัดเก็บ SSD 256GB และ หน่วยความจำรวมขนาด 8GB\r\nมาพร้อมระบบปฏิบัติการ mac OS', 99, 2),
(7, 'ชิป M3 ทำให้ MacBook Air รุ่น 15 นิ้ว ที่พกพาง่ายสุดๆ เครื่องนี้มาพร้อมความสามารถอันยอดเยี่ยมขึ้นไปอีก ด้วยแบตเตอรี่ที่ใช้งานได้นานสูงสุด 18 ชั่วโมง พร้อมจอภาพ Liquid Retina ที่กว้างเต็มตา คุณจึงพกพาไปที่ไหนก็ได้ แล้วยังรับมือทั้งเรื่องงานและเรื่องเล่นได้อย่างฉับไวด้วจอ 15.3\" ใหญ่และคมชัดชิป M3 ที่ทรงพลัง  ดีไซน์บางเฉียบและน้ำหนักเบาช่องต่อ Thunderbolt 4 สองช่องWi-Fi 6E, Bluetooth 5.3  รองรับการต่อจอภาพภายนอก 2 จอ', 99, 3),
(8, 'adsasdasdas', 12, 3),
(9, 'MSI Modern 15 H AI C1M อัดแน่นไปด้วยทุกสิ่งที่คุณต้องการ ให้ประสิทธิภาพอันน่าทึ่งขับเคลื่อนโดยโปรเซสเซอร์ Intel Core Ultra และมีประสิทธิภาพ Integrated NPU ล่าสุดยังเพิ่มพลังให้กับเวิร์กโหลดมากขึ้น เป็นตัวเลือกที่ดีที่สุดในการเร่งความเร็วโปรแกรม AI \r\n\r\nCPU:  Intel Core Ultra 7 155H (2.50GHz up to 4.80GHz, 16C(6P+8E+2LPE)/22T, 24MB Intel Smart Cache)\r\nGraphics:  Intel Arc Graphics\r\nRAM:  16GB (2x8GB) DDR5-5600\r\nSSD:  1TB NVMe PCIe  4.0 x4', 12, 2),
(10, 'เคสคอมพิวเตอร์ AeroCool Blade-G-BK-v1 เคสคอม Mid-Tower ที่มีการออกแบบแผงด้านหน้า RGB ที่เป็นเอกลักษณ์พร้อมโหมดแสง RGB ในตัว ช่องระบายอากาศที่แผงด้านหน้าช่วยให้อากาศไหลเวียนได้ดียิ่งขึ้น มาพร้อมกับแผงกระจกด้านข้างแบบเต็มเพื่อแสดงด้านในของอุปกรณ์ของคุณ\r\n\r\n•  รองรับ GPU ยาวสูงสุด 307 มม. \r\n• รองรับ CPU Air Cooler สูงสุด 155 มม.', 12, 4),
(11, 'คอมพิวเตอร์ที่เหมาะสำหรับการเล่นเกมที่ซีเรียสจริงจัง พร้อมการออกแบบสไตล์ใหม่ TUF Gaming A17 เป็นแล็ปท็อปสำหรับเกมที่สามารถพาคุณไปสู่ชัยชนะได้อย่างง่ายดาย กราฟิก GeForce RTX  พร้อมมอบการเล่นเกมที่ลื่นไหล  ในขณะเดียวกัน โปรเซสเซอร์หลัก AMD Ryzen 7 พร้อมระบบระบายความร้อนที่พัฒนาขึ้นใหม่ให้เสียงรบกวนที่เบาลงอย่างเห็นได้ชัด ', 12, 2),
(12, 'คอมพิวเตอร์ที่เหมาะสำหรับการเล่นเกมที่ซีเรียสจริงจัง พร้อมการออกแบบสไตล์ใหม่ TUF Gaming A17 เป็นแล็ปท็อปสำหรับเกมที่สามารถพาคุณไปสู่ชัยชนะได้อย่างง่ายดาย กราฟิก GeForce RTX  พร้อมมอบการเล่นเกมที่ลื่นไหล  ในขณะเดียวกัน โปรเซสเซอร์หลัก AMD Ryzen 7 พร้อมระบบระบายความร้อนที่พัฒนาขึ้นใหม่ให้เสียงรบกวนที่เบาลงอย่างเห็นได้ชัด ', 123, 2),
(13, 'MSI Modern 15 H AI C1M อัดแน่นไปด้วยทุกสิ่งที่คุณต้องการ ให้ประสิทธิภาพอันน่าทึ่งขับเคลื่อนโดยโปรเซสเซอร์ Intel Core Ultra และมีประสิทธิภาพ Integrated NPU ล่าสุดยังเพิ่มพลังให้กับเวิร์กโหลดมากขึ้น เป็นตัวเลือกที่ดีที่สุดในการเร่งความเร็วโปรแกรม AI \r\n\r\nCPU:  Intel Core Ultra 7 155H (2.50GHz up to 4.80GHz, 16C(6P+8E+2LPE)/22T, 24MB Intel Smart Cache)\r\nGraphics:  Intel Arc Graphics\r\nRAM:  16GB (2x8GB) DDR5-5600\r\nSSD:  1TB NVMe PCIe  4.0 x4', 2, 2),
(14, 'รายละเอียดสินค้าโดยย่อ\r\n\r\n• สามารถปรับเปลี่ยนอุปกรณ์ได้ตามที่ต้องการ\r\n• ทุกเซ็ตที่กำหนด จัดส่งฟรีภายใน 4 ชั่วโมง *เฉพาะกรุงเทพฯ และปริมณฑล\r\n• อุปกรณ์คอมพิวเตอร์เสียภายใน 30 วัน นับจากวันซื้อ เปลี่ยนอุปกรณ์คอมพิวเตอร์ใหม่ให้ทันที ภายใน 24 ชั่วโมง เฉพาะซื้อผ่าน JIB Online เท่านั้น (เงื่อนไขเป็นไปตามที่กำหนด)\r\n• ผ่อนสบายๆ 0% นาน 10 เดือน ทุกเซ็ต\r\n• บริการซ่อมและตรวจเช็คอาการ ฟรี! ได้ที่เจไอบีกว่า 155 สาขา ใน 70 จังหวัด', 123, 3),
(15, 'รายละเอียดสินค้าโดยย่อ\r\n\r\n• สามารถปรับเปลี่ยนอุปกรณ์ได้ตามที่ต้องการ\r\n• ทุกเซ็ตที่กำหนด จัดส่งฟรีภายใน 4 ชั่วโมง *เฉพาะกรุงเทพฯ และปริมณฑล\r\n• อุปกรณ์คอมพิวเตอร์เสียภายใน 30 วัน นับจากวันซื้อ เปลี่ยนอุปกรณ์คอมพิวเตอร์ใหม่ให้ทันที ภายใน 24 ชั่วโมง เฉพาะซื้อผ่าน JIB Online เท่านั้น (เงื่อนไขเป็นไปตามที่กำหนด)\r\n• ผ่อนสบายๆ 0% นาน 10 เดือน ทุกเซ็ต\r\n• บริการซ่อมและตรวจเช็คอาการ ฟรี! ได้ที่เจไอบีกว่า 155 สาขา ใน 70 จังหวัด', 123, 2),
(16, 'รายละเอียดสินค้าโดยย่อ\r\n\r\n• สามารถปรับเปลี่ยนอุปกรณ์ได้ตามที่ต้องการ\r\n• ทุกเซ็ตที่กำหนด จัดส่งฟรีภายใน 4 ชั่วโมง *เฉพาะกรุงเทพฯ และปริมณฑล\r\n• อุปกรณ์คอมพิวเตอร์เสียภายใน 30 วัน นับจากวันซื้อ เปลี่ยนอุปกรณ์คอมพิวเตอร์ใหม่ให้ทันที ภายใน 24 ชั่วโมง เฉพาะซื้อผ่าน JIB Online เท่านั้น (เงื่อนไขเป็นไปตามที่กำหนด)\r\n• ผ่อนสบายๆ 0% นาน 10 เดือน ทุกเซ็ต\r\n• บริการซ่อมและตรวจเช็คอาการ ฟรี! ได้ที่เจไอบีกว่า 155 สาขา ใน 70 จังหวัด', 123, 3),
(17, 'รายละเอียดสินค้าโดยย่อ\r\n\r\n• สามารถปรับเปลี่ยนอุปกรณ์ได้ตามที่ต้องการ\r\n• ทุกเซ็ตที่กำหนด จัดส่งฟรีภายใน 4 ชั่วโมง *เฉพาะกรุงเทพฯ และปริมณฑล\r\n• อุปกรณ์คอมพิวเตอร์เสียภายใน 30 วัน นับจากวันซื้อ เปลี่ยนอุปกรณ์คอมพิวเตอร์ใหม่ให้ทันที ภายใน 24 ชั่วโมง เฉพาะซื้อผ่าน JIB Online เท่านั้น (เงื่อนไขเป็นไปตามที่กำหนด)\r\n• ผ่อนสบายๆ 0% นาน 10 เดือน ทุกเซ็ต\r\n• บริการซ่อมและตรวจเช็คอาการ ฟรี! ได้ที่เจไอบีกว่า 155 สาขา ใน 70 จังหวัด', 123, 3),
(18, 'รายละเอียดสินค้าโดยย่อ\r\n\r\n• สามารถปรับเปลี่ยนอุปกรณ์ได้ตามที่ต้องการ\r\n• ทุกเซ็ตที่กำหนด จัดส่งฟรีภายใน 4 ชั่วโมง *เฉพาะกรุงเทพฯ และปริมณฑล\r\n• อุปกรณ์คอมพิวเตอร์เสียภายใน 30 วัน นับจากวันซื้อ เปลี่ยนอุปกรณ์คอมพิวเตอร์ใหม่ให้ทันที ภายใน 24 ชั่วโมง เฉพาะซื้อผ่าน JIB Online เท่านั้น (เงื่อนไขเป็นไปตามที่กำหนด)\r\n• ผ่อนสบายๆ 0% นาน 10 เดือน ทุกเซ็ต\r\n• บริการซ่อมและตรวจเช็คอาการ ฟรี! ได้ที่เจไอบีกว่า 155 สาขา ใน 70 จังหวัด', 123, 3),
(19, 'รายละเอียดสินค้าโดยย่อ\r\n\r\n• สามารถปรับเปลี่ยนอุปกรณ์ได้ตามที่ต้องการ\r\n• ทุกเซ็ตที่กำหนด จัดส่งฟรีภายใน 4 ชั่วโมง *เฉพาะกรุงเทพฯ และปริมณฑล\r\n• อุปกรณ์คอมพิวเตอร์เสียภายใน 30 วัน นับจากวันซื้อ เปลี่ยนอุปกรณ์คอมพิวเตอร์ใหม่ให้ทันที ภายใน 24 ชั่วโมง เฉพาะซื้อผ่าน JIB Online เท่านั้น (เงื่อนไขเป็นไปตามที่กำหนด)\r\n• ผ่อนสบายๆ 0% นาน 10 เดือน ทุกเซ็ต\r\n• บริการซ่อมและตรวจเช็คอาการ ฟรี! ได้ที่เจไอบีกว่า 155 สาขา ใน 70 จังหวัด', 123, 3);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ID` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `Name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `detail_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ID`, `image`, `Name`, `price`, `detail_id`) VALUES
(5, '../uploadsOIP.jpg', 'Apple MacBook Air 15 M3/256 MRYM3TH/A (Space Grey)', '49000.00', 4),
(10, '../uploadsimage_2024-10-17_142433650.png', 'MSI Modern 15 H AI C1MG-052TH Classic Black', '23000.00', 9),
(11, '../uploadsimage_2024-10-17_144319742.png', 'เคสคอมพิวเตอร์ AeroCool Computer Case Blade-G-BK-v1', '1980.00', 10),
(12, '../uploadsimage_2024-10-17_144513759.png', 'Asus TUF Gaming A17 FA706QR-HX025T Grey', '47000.00', 11),
(13, '../uploadsimage_2024-10-17_144914737.png', 'โน๊ตบุ๊ค Asus TUF Gaming A17 FA706QM-HX034T Grey', '37990.00', 12),
(14, '../uploadsimage_2024-10-17_144959728.png', 'MSI Modern 15 H AI C1MG-052TH Classic Black', '23990.00', 13),
(15, '../uploadsasd.png', 'COMPUTER SET JIB MARU-2410101', '38.00', 14),
(16, '../uploadsasd.png', 'COMPUTER SET JIB MARU-2410101', '38.00', 15),
(17, '../uploadsasd.png', 'COMPUTER SET JIB MARU-2410101', '38.00', 16),
(18, '../uploadsasd.png', 'COMPUTER SET JIB MARU-2410101', '38.00', 17),
(19, '../uploadsasd.png', 'COMPUTER SET JIB MARU-2410101', '38.00', 18),
(20, '../uploadsasd.png', 'COMPUTER SET JIB MARU-2410101', '38.00', 19);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `ID` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`ID`, `fname`, `lname`, `address`, `telephone`, `img`) VALUES
(1, 'admin', 'admin', 'admin', '0000000000', '../uploads/download20240603194915.png'),
(4, 'user', 'user', '2/34', '0000000000', '../uploads/download20240603193720.png');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `ID` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`ID`, `type`) VALUES
(2, 'Notebook'),
(3, 'Computer'),
(4, 'Outer');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `User` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `User`, `Email`, `Password`, `profile_id`, `role`) VALUES
(1, 'root', 'admin@gmail.com', '$2y$10$nPU.zwlmG/xPLQKir2B6ReszSNWLhJoBsyeVugCwDWU.TcuBzf4Be', 1, 1),
(4, 'user', 'user@gmail.com', '$2y$10$AXzyJZjClXCqLbpp8QWWIOnDtViuuhpelt2kSg4QIiawLYBZ9sUiG', 4, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_product`
--
ALTER TABLE `detail_product`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `type_id` (`type_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `detail_id` (`detail_id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `profile_id` (`profile_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_product`
--
ALTER TABLE `detail_product`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_product`
--
ALTER TABLE `detail_product`
  ADD CONSTRAINT `detail_product_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `type` (`ID`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`detail_id`) REFERENCES `detail_product` (`ID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
