<div class="sidebar">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="javascript:void(0)" class="simple-text logo-mini">
                JTP
            </a>
            <a href="javascript:void(0)" class="simple-text logo-normal">
                |  jaturapat
            </a>
        </div>
        <ul class="nav">
            <li>
                <a href="index.php">
                    <i class="tim-icons icon-chart-pie-36"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li>
                <a href="index_Showuser.php">
                    <i class="tim-icons icon-atom"></i>
                    <p>ShowUserdata</p>
                </a>
            </li>
            <li>
                <a href="index_edituser.php">
                    <i class="tim-icons icon-pin"></i>
                    <p>Edituser</p>
                </a>
            </li>
            <li>
                <a href="index_addproduct.php">
                    <i class="tim-icons icon-bell-55"></i>
                    <p>Addproduct</p>
                </a>
            </li>
            <li>
                <a href="index_showproduct.php">
                    <i class="tim-icons icon-single-02"></i>
                    <p>Showproduct</p>
                </a>
            </li>
            
        </ul>
    </div>
</div>