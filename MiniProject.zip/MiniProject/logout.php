<?php
session_start();
session_unset(); // ลบตัวแปรเซสชันทั้งหมด
session_destroy(); // ทำลายเซสชัน
// เปลี่ยนเส้นทางไปยังหน้าล็อกอิน
header('Location: Login.php');
exit;
?>
